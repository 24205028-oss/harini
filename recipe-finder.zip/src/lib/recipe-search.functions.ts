import { createServerFn } from "@tanstack/react-start";
import type { Recipe } from "@/data/recipes";

type SpoonNutrient = { name: string; amount: number; unit: string };
type SpoonIngredient = { original?: string; originalString?: string };
type SpoonStep = { number: number; step: string };
type SpoonInstructionBlock = { steps: SpoonStep[] };

type SpoonResult = {
  id: number;
  title: string;
  image: string;
  readyInMinutes?: number;
  servings?: number;
  sourceUrl?: string;
  spoonacularSourceUrl?: string;
  spoonacularScore?: number;
  aggregateLikes?: number;
  cuisines?: string[];
  dishTypes?: string[];
  summary?: string;
  extendedIngredients?: SpoonIngredient[];
  analyzedInstructions?: SpoonInstructionBlock[];
  nutrition?: { nutrients?: SpoonNutrient[] };
};

const CATEGORY_MAP: Record<string, string> = {
  indian: "indian",
  chinese: "chinese",
  korean: "korean",
  japanese: "japanese",
  mexican: "mexican",
  italian: "italian",
  american: "american",
  thai: "chinese",
  french: "desserts",
  "middle eastern": "arabic",
  mediterranean: "arabic",
  african: "arabic",
  vietnamese: "chinese",
  spanish: "italian",
  greek: "italian",
};

function classify(cuisines: string[] = [], dishTypes: string[] = []): string {
  for (const c of cuisines) {
    const key = c.toLowerCase();
    if (CATEGORY_MAP[key]) return CATEGORY_MAP[key];
  }
  const dt = dishTypes.map((d) => d.toLowerCase());
  if (dt.some((d) => d.includes("dessert"))) return "desserts";
  if (dt.some((d) => d.includes("drink") || d.includes("beverage"))) return "drinks";
  if (dt.some((d) => d.includes("snack") || d.includes("fingerfood"))) return "street";
  if (dt.some((d) => d.includes("salad") || d.includes("soup"))) return "healthy";
  return "all";
}

function stripHtml(s: string): string {
  return s.replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
}

function transform(r: SpoonResult): Recipe {
  const cuisine = r.cuisines?.[0] || r.dishTypes?.[0] || "Worldwide";
  const time = r.readyInMinutes ?? 30;
  const cal = r.nutrition?.nutrients?.find((n) => n.name === "Calories")?.amount;
  const calories = Math.round(cal ?? 0) || 400;
  const rating = r.spoonacularScore
    ? Math.max(3.5, Math.min(5, Math.round((r.spoonacularScore / 20) * 10) / 10))
    : 4.5;

  const ingredients =
    r.extendedIngredients?.map((i) => i.original || i.originalString || "").filter(Boolean) ?? [];

  const steps =
    r.analyzedInstructions?.[0]?.steps?.map((s) => s.step).filter(Boolean) ?? [];

  return {
    id: `sp-${r.id}`,
    title: r.title,
    cuisine,
    category: classify(r.cuisines, r.dishTypes),
    time,
    difficulty: time < 25 ? "Easy" : time < 50 ? "Medium" : "Hard",
    rating,
    calories,
    servings: r.servings ?? 2,
    image: r.image,
    description: r.summary ? stripHtml(r.summary).slice(0, 160) + "…" : "",
    ingredients,
    steps: steps.length ? steps : ["Visit the source for full step-by-step instructions."],
    youtube: r.sourceUrl || r.spoonacularSourceUrl || undefined,
    area: r.cuisines?.[0],
  };
}

export const searchRecipes = createServerFn({ method: "GET" })
  .inputValidator((input: { query: string }) => {
    const q = (input?.query ?? "").trim().slice(0, 100);
    return { query: q };
  })
  .handler(async ({ data }): Promise<{ recipes: Recipe[]; error: string | null }> => {
    if (!data.query) return { recipes: [], error: null };

    const apiKey = process.env.SPOONACULAR_API_KEY;
    if (!apiKey) {
      return { recipes: [], error: "Recipe API is not configured." };
    }

    const url = new URL("https://api.spoonacular.com/recipes/complexSearch");
    url.searchParams.set("query", data.query);
    url.searchParams.set("number", "24");
    url.searchParams.set("addRecipeInformation", "true");
    url.searchParams.set("addRecipeNutrition", "true");
    url.searchParams.set("instructionsRequired", "true");
    url.searchParams.set("apiKey", apiKey);

    try {
      const res = await fetch(url.toString());
      if (!res.ok) {
        const text = await res.text().catch(() => "");
        console.error("Spoonacular error:", res.status, text);
        if (res.status === 401 || res.status === 402) {
          return { recipes: [], error: "Recipe API quota reached or key invalid." };
        }
        return { recipes: [], error: `Recipe service error (${res.status}).` };
      }
      const json = (await res.json()) as { results?: SpoonResult[] };
      const recipes = (json.results ?? []).map(transform);
      return { recipes, error: null };
    } catch (e) {
      console.error("Spoonacular fetch failed:", e);
      return { recipes: [], error: "Recipe service is currently unavailable." };
    }
  });
