import { createFileRoute } from "@tanstack/react-router";
import { forwardRef, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Search, Heart, Clock, Star, Flame, ChefHat, X, Menu, Sparkles, Pizza, Soup,
  Salad, Beef, Fish, Croissant, IceCream, Utensils, Leaf, Carrot, Shell, Wine,
  Sandwich, ArrowRight, ChevronLeft, ChevronRight, Award, Twitter, Instagram,
  Youtube, Facebook, Users, Zap, BookOpen, PlayCircle, SearchX,
} from "lucide-react";
import { categories, recipes, type Recipe } from "@/data/recipes";
import { useServerFn } from "@tanstack/react-start";
import { searchRecipes } from "@/lib/recipe-search.functions";


export const Route = createFileRoute("/")({ component: Index });

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Sparkles, Flame, Soup, Pizza, Salad, Beef, ChefHat, Fish, Croissant, IceCream,
  Utensils, Leaf, Carrot, Shell, Wine, Sandwich,
};

function Index() {
  const [query, setQuery] = useState("");
  const [active, setActive] = useState<string>("all");
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [selected, setSelected] = useState<Recipe | null>(null);
  const [loading, setLoading] = useState(true);
  const [menuOpen, setMenuOpen] = useState(false);

  const [searchResults, setSearchResults] = useState<Recipe[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [searchedTerm, setSearchedTerm] = useState("");
  const resultsRef = useRef<HTMLDivElement>(null);
  const searchFn = useServerFn(searchRecipes);

  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 700);
    return () => clearTimeout(t);
  }, []);

  const runSearch = async (raw: string) => {
    const q = raw.trim();
    if (!q) {
      setSearchResults(null);
      setSearchError(null);
      setSearchedTerm("");
      return;
    }
    setSearching(true);
    setSearchError(null);
    setSearchedTerm(q);
    try {
      const { recipes: results, error } = await searchFn({ data: { query: q } });
      if (error) {
        setSearchError(error);
        setSearchResults([]);
      } else {
        setSearchResults(results);
      }
      setTimeout(() => {
        resultsRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 50);
    } catch (e) {
      setSearchError(e instanceof Error ? e.message : "Something went wrong.");
      setSearchResults([]);
    } finally {
      setSearching(false);
    }
  };


  const clearSearch = () => {
    setSearchResults(null);
    setSearchError(null);
    setSearchedTerm("");
    setQuery("");
  };

  const toggleFav = (id: string) =>
    setFavorites((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  const filtered = useMemo(() => {
    return recipes.filter((r) => {
      const matchesCat = active === "all" || r.category === active;
      return matchesCat;
    });
  }, [active]);

  const trending = recipes.filter((r) => r.trending);
  const popular = recipes.filter((r) => r.popular);
  const chefPick = recipes.find((r) => r.chefPick)!;


  return (
    <div className="relative min-h-screen overflow-x-hidden text-foreground">
      <FloatingIcons />
      <Navbar menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <main className="relative">
        <Hero query={query} setQuery={setQuery} onSearch={runSearch} searching={searching} />

        <SearchResults
          ref={resultsRef}
          term={searchedTerm}
          results={searchResults}
          loading={searching}
          error={searchError}
          favorites={favorites}
          toggleFav={toggleFav}
          onOpen={setSelected}
          onClear={clearSearch}
        />

        <CategorySection active={active} setActive={setActive} />

        <Section
          id="trending"
          eyebrow="Trending Now"
          title="What everyone's cooking this week"
          icon={<Flame className="h-4 w-4" />}
        >
          {loading ? (
            <SkeletonGrid />
          ) : (
            <CardGrid
              recipes={active !== "all" ? filtered : trending}
              favorites={favorites}
              toggleFav={toggleFav}
              onOpen={setSelected}
            />
          )}
        </Section>


        <PopularCarousel
          recipes={popular}
          favorites={favorites}
          toggleFav={toggleFav}
          onOpen={setSelected}
        />

        <FeaturedBanner recipe={chefPick} onOpen={setSelected} />

        <ChefSpecial recipes={recipes.filter((r) => r.chefPick)} onOpen={setSelected} />

        <Footer />
      </main>

      <AnimatePresence>
        {selected && (
          <RecipeModal
            recipe={selected}
            onClose={() => setSelected(null)}
            isFav={favorites.has(selected.id)}
            toggleFav={() => toggleFav(selected.id)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

/* ---------- Search Results ---------- */
type SearchResultsProps = {
  term: string;
  results: Recipe[] | null;
  loading: boolean;
  error: string | null;
  favorites: Set<string>;
  toggleFav: (id: string) => void;
  onOpen: (r: Recipe) => void;
  onClear: () => void;
};

const SearchResults = forwardRef<HTMLDivElement, SearchResultsProps>(function SearchResults(
  { term, results, loading, error, favorites, toggleFav, onOpen, onClear },
  ref,
) {
  if (!loading && results === null && !error) return <div ref={ref} />;

  return (
    <section ref={ref} id="search-results" className="relative py-12 scroll-mt-24">
      <div className="mx-auto max-w-7xl px-5">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="mb-6 flex flex-wrap items-end justify-between gap-3"
        >
          <div>
            <p className="inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-widest text-primary">
              <Search className="h-4 w-4" /> Search Results
            </p>
            <h2 className="mt-1 text-3xl font-bold sm:text-4xl">
              {loading ? (
                <>Searching for <span className="text-gradient-warm">"{term}"</span>…</>
              ) : (
                <>
                  {results?.length ?? 0} result{(results?.length ?? 0) === 1 ? "" : "s"} for{" "}
                  <span className="text-gradient-warm">"{term}"</span>
                </>
              )}
            </h2>
          </div>
          <button
            onClick={onClear}
            className="inline-flex items-center gap-1.5 rounded-full glass px-4 py-2 text-xs font-medium text-white/70 transition hover:text-white"
          >
            <X className="h-3.5 w-3.5" /> Clear search
          </button>
        </motion.div>

        {loading ? (
          <SkeletonGrid />
        ) : error ? (
          <div className="glass rounded-3xl py-20 text-center">
            <p className="text-lg text-white/80">Couldn't reach the recipe service.</p>
            <p className="mt-1 text-sm text-white/50">{error}</p>
          </div>
        ) : results && results.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass rounded-3xl py-20 text-center"
          >
            <SearchX className="mx-auto h-10 w-10 text-primary/70" />
            <p className="mt-4 text-lg font-semibold text-white/90">No recipes found</p>
            <p className="mt-1 text-sm text-white/55">
              Try "chicken", "pasta", "curry", "shrimp" or "dessert".
            </p>
          </motion.div>
        ) : (
          <CardGrid
            recipes={results ?? []}
            favorites={favorites}
            toggleFav={toggleFav}
            onOpen={onOpen}
          />
        )}
      </div>
    </section>
  );
});


/* ---------- Floating decorative icons ---------- */
function FloatingIcons() {
  const items = [
    { Icon: Pizza, top: "8%", left: "4%", delay: "0s", size: 32 },
    { Icon: IceCream, top: "22%", right: "6%", delay: "1.2s", size: 28 },
    { Icon: Soup, top: "55%", left: "3%", delay: "2.4s", size: 30 },
    { Icon: Croissant, top: "70%", right: "5%", delay: "0.8s", size: 26 },
    { Icon: Fish, top: "40%", left: "92%", delay: "1.8s", size: 28 },
  ];
  return (
    <div className="pointer-events-none fixed inset-0 z-0">
      {items.map(({ Icon, delay, size, ...pos }, i) => (
        <div
          key={i}
          className="animate-float-soft absolute text-primary/20"
          style={{ ...pos, animationDelay: delay }}
        >
          <Icon className="drop-shadow-[0_0_20px_rgba(249,115,22,0.4)]" {...({ size } as any)} />
        </div>
      ))}
    </div>
  );
}

/* ---------- Navbar ---------- */
function Navbar({ menuOpen, setMenuOpen }: { menuOpen: boolean; setMenuOpen: (b: boolean) => void }) {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = ["Recipes", "Cuisines", "Chefs", "Trending", "About"];

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled ? "py-3" : "py-5"
      }`}
    >
      <div
        className={`mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 transition-all ${
          scrolled
            ? "glass-strong mx-4 rounded-2xl py-2.5 md:mx-auto"
            : ""
        }`}
      >
        <a href="#" className="flex items-center gap-2.5">
          <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-[#fb923c] to-[#f97316] shadow-lg shadow-orange-500/30">
            <ChefHat className="h-5 w-5 text-white" />
          </div>
          <span className="text-lg font-bold tracking-tight">
            Saffron<span className="text-primary">.</span>
          </span>
        </a>

        <nav className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <a
              key={l}
              href={`#${l.toLowerCase()}`}
              className="rounded-full px-4 py-2 text-sm text-white/70 transition-all hover:bg-white/5 hover:text-white"
            >
              {l}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button className="hidden rounded-full bg-gradient-to-r from-[#f97316] to-[#fb923c] px-5 py-2 text-sm font-semibold text-white shadow-lg shadow-orange-500/30 transition-all hover:scale-105 hover:shadow-orange-500/50 md:inline-flex">
            Get Started
          </button>
          <button
            className="grid h-10 w-10 place-items-center rounded-full bg-white/5 md:hidden"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Menu"
          >
            {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="glass-strong mx-4 mt-3 rounded-2xl p-4 md:hidden"
          >
            {links.map((l) => (
              <a
                key={l}
                href={`#${l.toLowerCase()}`}
                onClick={() => setMenuOpen(false)}
                className="block rounded-xl px-3 py-3 text-base text-white/80 hover:bg-white/5"
              >
                {l}
              </a>
            ))}
            <button className="mt-2 w-full rounded-xl bg-gradient-to-r from-[#f97316] to-[#fb923c] py-3 text-sm font-semibold">
              Get Started
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

/* ---------- Hero ---------- */
function Hero({
  query,
  setQuery,
  onSearch,
  searching,
}: {
  query: string;
  setQuery: (s: string) => void;
  onSearch: (q: string) => void;
  searching: boolean;
}) {
  const submit = () => onSearch(query);

  return (
    <section className="relative isolate pt-36 pb-24 sm:pt-44">
      <div className="absolute inset-0 -z-10">
        <img
          src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1900&q=80"
          alt=""
          className="h-full w-full object-cover opacity-25"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/80 to-background" />
      </div>

      <div className="mx-auto max-w-6xl px-5 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mx-auto inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs font-medium text-white/80"
        >
          <Sparkles className="h-3.5 w-3.5 text-accent" />
          15+ cuisines · 10,000+ recipes · curated daily
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="mt-6 text-balance text-5xl font-extrabold leading-[1.05] tracking-tight sm:text-7xl"
        >
          Discover flavors{" "}
          <span className="text-gradient-warm" style={{ fontFamily: "'Instrument Serif', serif", fontWeight: 400 }}>
            from every corner
          </span>{" "}
          of the world.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mx-auto mt-5 max-w-2xl text-base text-white/65 sm:text-lg"
        >
          A premium food-discovery platform — Indian curries, Japanese sushi, Italian pasta,
          Mexican street food and everything in between, with step-by-step guides.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="mx-auto mt-10 max-w-2xl"
        >
          <div className="group relative">
            <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-[#f97316] via-[#facc15] to-[#fb923c] opacity-60 blur-xl transition group-focus-within:opacity-100" />
            <div className="glass-strong relative flex items-center gap-3 rounded-full p-2 pl-6 glow-ring">
              <Search className="h-5 w-5 text-white/60" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    submit();
                  }
                }}
                placeholder="Search butter chicken, ramen, tacos…"
                className="w-full bg-transparent py-3 text-base outline-none placeholder:text-white/40"
              />
              <button
                onClick={submit}
                disabled={searching}
                className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-[#f97316] to-[#fb923c] px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-orange-500/40 transition-all hover:scale-105 disabled:opacity-70"
              >
                {searching ? (
                  <>
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                    Searching
                  </>
                ) : (
                  "Search"
                )}
              </button>
            </div>
          </div>


          <div className="mt-5 flex flex-wrap items-center justify-center gap-2 text-xs text-white/50">
            <span>Popular:</span>
            {["Ramen", "Biryani", "Tacos", "Sushi", "Tiramisu"].map((t) => (
              <button
                key={t}
                onClick={() => { setQuery(t); onSearch(t); }}
                className="rounded-full bg-white/5 px-3 py-1 transition hover:bg-white/10 hover:text-white"
              >
                {t}
              </button>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.45 }}
          className="mx-auto mt-14 grid max-w-3xl grid-cols-3 gap-4"
        >
          {[
            { Icon: BookOpen, n: "10k+", l: "Recipes" },
            { Icon: Users, n: "2M+", l: "Home cooks" },
            { Icon: Zap, n: "15+", l: "Cuisines" },
          ].map(({ Icon, n, l }) => (
            <div key={l} className="glass rounded-2xl px-4 py-5">
              <Icon className="mx-auto h-5 w-5 text-primary" />
              <div className="mt-2 text-2xl font-bold">{n}</div>
              <div className="text-xs text-white/60">{l}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

/* ---------- Categories ---------- */
function CategorySection({
  active,
  setActive,
}: {
  active: string;
  setActive: (s: string) => void;
}) {
  return (
    <section id="cuisines" className="relative py-12">
      <div className="mx-auto max-w-7xl px-5">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <p className="text-xs font-medium uppercase tracking-widest text-primary">Browse</p>
            <h2 className="mt-1 text-3xl font-bold sm:text-4xl">Pick a cuisine</h2>
          </div>
        </div>

        <div className="scroll-hide flex gap-3 overflow-x-auto pb-2">
          {categories.map((c) => {
            const Icon = iconMap[c.icon] ?? Sparkles;
            const isActive = active === c.id;
            return (
              <motion.button
                key={c.id}
                whileHover={{ scale: 1.04, y: -2 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => setActive(c.id)}
                className={`flex shrink-0 items-center gap-2 rounded-2xl px-5 py-3 text-sm font-medium transition-all ${
                  isActive
                    ? "bg-gradient-to-br from-[#f97316] to-[#fb923c] text-white shadow-lg shadow-orange-500/40"
                    : "glass text-white/80 hover:text-white"
                }`}
              >
                <Icon className="h-4 w-4" />
                {c.label}
              </motion.button>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ---------- Section wrapper ---------- */
function Section({
  id, eyebrow, title, icon, children,
}: {
  id?: string; eyebrow: string; title: string; icon?: React.ReactNode; children: React.ReactNode;
}) {
  return (
    <section id={id} className="relative py-14">
      <div className="mx-auto max-w-7xl px-5">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6 }}
          className="mb-8 flex items-end justify-between"
        >
          <div>
            <p className="inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-widest text-primary">
              {icon} {eyebrow}
            </p>
            <h2 className="mt-1 text-3xl font-bold sm:text-4xl">{title}</h2>
          </div>
          <a href="#" className="hidden items-center gap-1 text-sm text-white/60 transition hover:text-white sm:flex">
            View all <ArrowRight className="h-4 w-4" />
          </a>
        </motion.div>
        {children}
      </div>
    </section>
  );
}

/* ---------- Card grid ---------- */
function CardGrid({
  recipes, favorites, toggleFav, onOpen,
}: {
  recipes: Recipe[]; favorites: Set<string>; toggleFav: (id: string) => void; onOpen: (r: Recipe) => void;
}) {
  if (recipes.length === 0) {
    return (
      <div className="glass rounded-3xl py-20 text-center">
        <p className="text-lg text-white/70">No recipes match your search.</p>
        <p className="mt-1 text-sm text-white/50">Try a different cuisine or keyword.</p>
      </div>
    );
  }
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {recipes.map((r, i) => (
        <RecipeCard
          key={r.id}
          recipe={r}
          index={i}
          isFav={favorites.has(r.id)}
          toggleFav={() => toggleFav(r.id)}
          onOpen={() => onOpen(r)}
        />
      ))}
    </div>
  );
}

function RecipeCard({
  recipe: r, index, isFav, toggleFav, onOpen,
}: {
  recipe: Recipe; index: number; isFav: boolean; toggleFav: () => void; onOpen: () => void;
}) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, delay: (index % 4) * 0.06 }}
      whileHover={{ y: -6 }}
      onClick={onOpen}
      className="group glass relative cursor-pointer overflow-hidden rounded-3xl transition-all hover:shadow-2xl hover:shadow-orange-500/10"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={r.image}
          alt={r.title}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />

        <button
          onClick={(e) => { e.stopPropagation(); toggleFav(); }}
          className="absolute right-3 top-3 grid h-10 w-10 place-items-center rounded-full glass-strong transition-all hover:scale-110"
          aria-label="Favorite"
        >
          <Heart
            className={`h-4 w-4 transition-all ${isFav ? "fill-[#f97316] text-[#f97316]" : "text-white"}`}
          />
        </button>

        <div className="absolute left-3 top-3 inline-flex items-center gap-1 rounded-full bg-black/40 px-2.5 py-1 text-[11px] font-medium backdrop-blur">
          <span className="text-accent">●</span> {r.cuisine}
        </div>

        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-xs text-white/90">
          <span className="inline-flex items-center gap-1 rounded-full glass-strong px-2.5 py-1">
            <Clock className="h-3 w-3" /> {r.time} min
          </span>
          <span className="inline-flex items-center gap-1 rounded-full glass-strong px-2.5 py-1">
            <Star className="h-3 w-3 fill-accent text-accent" /> {r.rating}
          </span>
        </div>
      </div>

      <div className="p-4">
        <h3 className="line-clamp-1 text-base font-semibold">{r.title}</h3>
        <p className="mt-1 line-clamp-2 text-xs text-white/55">{r.description}</p>
        <div className="mt-3 flex items-center justify-between text-xs">
          <span
            className={`rounded-full px-2 py-0.5 font-medium ${
              r.difficulty === "Easy"
                ? "bg-emerald-500/15 text-emerald-300"
                : r.difficulty === "Medium"
                ? "bg-amber-500/15 text-amber-300"
                : "bg-rose-500/15 text-rose-300"
            }`}
          >
            {r.difficulty}
          </span>
          <span className="text-white/40">{r.calories} kcal</span>
        </div>
      </div>
    </motion.article>
  );
}

function SkeletonGrid() {
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="glass overflow-hidden rounded-3xl">
          <div className="aspect-[4/3] animate-pulse bg-white/5" />
          <div className="space-y-2 p-4">
            <div className="h-4 w-3/4 animate-pulse rounded bg-white/5" />
            <div className="h-3 w-full animate-pulse rounded bg-white/5" />
            <div className="h-3 w-2/3 animate-pulse rounded bg-white/5" />
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------- Popular carousel ---------- */
function PopularCarousel({
  recipes, favorites, toggleFav, onOpen,
}: {
  recipes: Recipe[]; favorites: Set<string>; toggleFav: (id: string) => void; onOpen: (r: Recipe) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const scroll = (dir: 1 | -1) => {
    ref.current?.scrollBy({ left: dir * 360, behavior: "smooth" });
  };

  return (
    <section id="trending" className="relative py-14">
      <div className="mx-auto max-w-7xl px-5">
        <div className="mb-8 flex items-end justify-between gap-4">
          <div>
            <p className="inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-widest text-primary">
              <Award className="h-4 w-4" /> Popular Dishes
            </p>
            <h2 className="mt-1 text-3xl font-bold sm:text-4xl">Most loved this season</h2>
          </div>
          <div className="hidden gap-2 sm:flex">
            <button
              onClick={() => scroll(-1)}
              className="grid h-10 w-10 place-items-center rounded-full glass transition hover:bg-white/10"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              onClick={() => scroll(1)}
              className="grid h-10 w-10 place-items-center rounded-full glass transition hover:bg-white/10"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div ref={ref} className="scroll-hide flex gap-5 overflow-x-auto pb-4">
          {recipes.map((r, i) => (
            <div key={r.id} className="w-[300px] shrink-0 sm:w-[340px]">
              <RecipeCard
                recipe={r}
                index={i}
                isFav={favorites.has(r.id)}
                toggleFav={() => toggleFav(r.id)}
                onOpen={() => onOpen(r)}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Featured banner ---------- */
function FeaturedBanner({ recipe, onOpen }: { recipe: Recipe; onOpen: (r: Recipe) => void }) {
  return (
    <section className="relative py-14">
      <div className="mx-auto max-w-7xl px-5">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="glass-strong relative grid overflow-hidden rounded-[2rem] md:grid-cols-2"
        >
          <div className="relative h-72 md:h-auto">
            <img src={recipe.image} alt={recipe.title} className="h-full w-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-r from-background/80 via-transparent to-transparent md:bg-gradient-to-r" />
          </div>
          <div className="relative p-8 md:p-12">
            <p className="inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-widest text-accent">
              <Sparkles className="h-3.5 w-3.5" /> Featured Recipe
            </p>
            <h3 className="mt-4 text-4xl font-bold leading-tight sm:text-5xl">
              {recipe.title}
            </h3>
            <p className="mt-4 max-w-md text-white/65">{recipe.description}</p>

            <div className="mt-6 flex flex-wrap gap-3 text-sm">
              <span className="glass rounded-full px-3 py-1.5">
                <Clock className="mr-1 inline h-3.5 w-3.5" />
                {recipe.time} min
              </span>
              <span className="glass rounded-full px-3 py-1.5">
                <Star className="mr-1 inline h-3.5 w-3.5 fill-accent text-accent" />
                {recipe.rating} rating
              </span>
              <span className="glass rounded-full px-3 py-1.5">
                <Flame className="mr-1 inline h-3.5 w-3.5 text-primary" />
                {recipe.calories} kcal
              </span>
            </div>

            <button
              onClick={() => onOpen(recipe)}
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-[#f97316] to-[#fb923c] px-6 py-3 text-sm font-semibold shadow-lg shadow-orange-500/40 transition-all hover:scale-105"
            >
              View recipe <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

/* ---------- Chef's special ---------- */
function ChefSpecial({ recipes, onOpen }: { recipes: Recipe[]; onOpen: (r: Recipe) => void }) {
  return (
    <section id="chefs" className="relative py-14">
      <div className="mx-auto max-w-7xl px-5">
        <div className="mb-10 grid items-end gap-6 md:grid-cols-[1fr_auto]">
          <div>
            <p className="inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-widest text-primary">
              <ChefHat className="h-4 w-4" /> Chef's Special
            </p>
            <h2 className="mt-1 text-3xl font-bold sm:text-4xl">
              Hand-picked by Chef Aurelia Moreno
            </h2>
            <p className="mt-2 max-w-2xl text-white/60">
              Michelin-trained, born in Mexico City — Aurelia curates a weekly selection of bold,
              soulful dishes you can master at home.
            </p>
          </div>
          <div className="flex items-center gap-3 glass rounded-2xl p-3 pr-5">
            <img
              src="https://images.unsplash.com/photo-1581299894007-aaa50297cf16?auto=format&fit=crop&w=200&q=80"
              alt="Chef Aurelia"
              className="h-12 w-12 rounded-xl object-cover"
            />
            <div>
              <div className="text-sm font-semibold">Aurelia Moreno</div>
              <div className="text-xs text-white/55">Executive Chef · ★ 4.9</div>
            </div>
          </div>
        </div>

        <div className="grid gap-5 md:grid-cols-3">
          {recipes.map((r, i) => (
            <motion.div
              key={r.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.55, delay: i * 0.08 }}
              whileHover={{ y: -6 }}
              onClick={() => onOpen(r)}
              className="group glass relative cursor-pointer overflow-hidden rounded-3xl"
            >
              <div className="relative aspect-[5/6] overflow-hidden">
                <img
                  src={r.image}
                  alt={r.title}
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-6">
                  <span className="inline-flex items-center gap-1 rounded-full bg-accent/90 px-2.5 py-1 text-[11px] font-semibold text-black">
                    <Award className="h-3 w-3" /> Chef's Pick
                  </span>
                  <h3 className="mt-3 text-2xl font-bold leading-tight">{r.title}</h3>
                  <p className="mt-1 line-clamp-2 text-sm text-white/70">{r.description}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Modal ---------- */
function RecipeModal({
  recipe, onClose, isFav, toggleFav,
}: {
  recipe: Recipe; onClose: () => void; isFav: boolean; toggleFav: () => void;
}) {
  useEffect(() => {
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [onClose]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] grid place-items-center bg-black/70 p-4 backdrop-blur-md"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.92, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.94, y: 20 }}
        transition={{ type: "spring", damping: 24, stiffness: 240 }}
        onClick={(e) => e.stopPropagation()}
        className="relative max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-3xl bg-[#111827]/95 shadow-2xl ring-1 ring-white/10"
      >
        <div className="relative h-72 overflow-hidden sm:h-96">
          <img src={recipe.image} alt={recipe.title} className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#111827] via-[#111827]/30 to-transparent" />
          <button
            onClick={onClose}
            className="absolute right-4 top-4 grid h-10 w-10 place-items-center rounded-full glass-strong hover:bg-white/20"
          >
            <X className="h-4 w-4" />
          </button>
          <button
            onClick={toggleFav}
            className="absolute right-16 top-4 grid h-10 w-10 place-items-center rounded-full glass-strong hover:bg-white/20"
          >
            <Heart className={`h-4 w-4 ${isFav ? "fill-[#f97316] text-[#f97316]" : "text-white"}`} />
          </button>
          <div className="absolute inset-x-0 bottom-0 p-6 sm:p-8">
            <p className="text-xs font-medium uppercase tracking-widest text-accent">{recipe.cuisine}</p>
            <h2 className="mt-2 text-3xl font-bold sm:text-4xl">{recipe.title}</h2>
            <p className="mt-2 max-w-2xl text-sm text-white/70">{recipe.description}</p>
          </div>
        </div>

        <div className="grid gap-3 px-6 py-5 sm:grid-cols-4 sm:px-8">
          {[
            { Icon: Clock, label: "Prep time", value: `${recipe.time} min` },
            { Icon: Flame, label: "Calories", value: `${recipe.calories} kcal` },
            { Icon: Users, label: "Servings", value: `${recipe.servings}` },
            { Icon: Star, label: "Rating", value: `${recipe.rating} / 5` },
          ].map(({ Icon, label, value }) => (
            <div key={label} className="glass rounded-2xl p-3">
              <Icon className="h-4 w-4 text-primary" />
              <div className="mt-2 text-[11px] uppercase tracking-wider text-white/50">{label}</div>
              <div className="text-sm font-semibold">{value}</div>
            </div>
          ))}
        </div>

        <div className="grid gap-8 px-6 pb-10 sm:grid-cols-[1fr_1.4fr] sm:px-8">
          <div>
            <h3 className="text-lg font-bold">Ingredients</h3>
            <ul className="mt-4 space-y-2">
              {recipe.ingredients.map((it) => (
                <li key={it} className="flex items-start gap-2 text-sm text-white/80">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  {it}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-bold">Step-by-step</h3>
            <ol className="mt-4 space-y-3">
              {recipe.steps.map((s, i) => (
                <li key={i} className="flex gap-3">
                  <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-gradient-to-br from-[#f97316] to-[#fb923c] text-xs font-bold text-white">
                    {i + 1}
                  </span>
                  <p className="text-sm leading-relaxed text-white/85">{s}</p>
                </li>
              ))}
            </ol>
            {recipe.youtube && (
              <a
                href={recipe.youtube}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-6 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-rose-500 to-red-600 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-red-500/30 transition hover:scale-105"
              >
                <PlayCircle className="h-4 w-4" /> Watch on YouTube
              </a>
            )}
          </div>
        </div>

      </motion.div>
    </motion.div>
  );
}

/* ---------- Footer ---------- */
function Footer() {
  const socials = [Twitter, Instagram, Youtube, Facebook];
  return (
    <footer id="about" className="relative mt-12 border-t border-white/5 pt-16 pb-10">
      <div className="mx-auto max-w-7xl px-5">
        <div className="grid gap-10 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2.5">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-[#fb923c] to-[#f97316] shadow-lg shadow-orange-500/30">
                <ChefHat className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold">Saffron<span className="text-primary">.</span></span>
            </div>
            <p className="mt-4 max-w-sm text-sm text-white/55">
              A premium recipe discovery platform — curated cuisines, trending dishes and
              chef-tested techniques from every corner of the world.
            </p>
            <div className="mt-6 flex gap-3">
              {socials.map((S, i) => (
                <a
                  key={i}
                  href="#"
                  className="grid h-10 w-10 place-items-center rounded-full glass transition hover:bg-primary/20 hover:text-primary"
                >
                  <S className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {[
            { title: "Explore", items: ["Recipes", "Cuisines", "Trending", "Chef's Pick"] },
            { title: "Company", items: ["About", "Careers", "Press", "Contact"] },
          ].map((col) => (
            <div key={col.title}>
              <h4 className="text-sm font-semibold uppercase tracking-widest text-white/80">{col.title}</h4>
              <ul className="mt-4 space-y-2 text-sm text-white/55">
                {col.items.map((i) => (
                  <li key={i}>
                    <a href="#" className="transition hover:text-white">{i}</a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-white/5 pt-6 text-xs text-white/40 sm:flex-row">
          <p>© {new Date().getFullYear()} Saffron. Crafted with flavor.</p>
          <p>Privacy · Terms · Cookies</p>
        </div>
      </div>
    </footer>
  );
}
